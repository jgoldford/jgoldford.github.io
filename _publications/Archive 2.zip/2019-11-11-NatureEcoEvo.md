---
title: "Environmental boundary conditions for the origin of life converge to an organo-sulfur metabolism"
collection: publications
permalink: /publication/2019-11-11-NatureEcoEvo
excerpt: ''
date: 2019-11-11
venue: 'Nature Ecology & Evolution'
paperurl: 'https://www.nature.com/articles/s41559-019-1018-8'
citation: 'Goldford, J. E., Hartman, H., Marsland R.,  Segre, D. &quot;Environmental boundary conditions for the origin of life converge to an organo-sulfur metabolism &quot; <i>Nature Ecology & Evolution</i>. (3)1715-1724'
---

[Download paper here](http://jgoldford.github.io/files/Goldford_NatureEcoEvo.pdf)

Recommended citation: Goldford, J. E., Hartman, H., Marsland R.,  Segre, D. "Environmental boundary conditions for the origin of life converge to an organo-sulfur metabolism." <i>Nature Ecology & Evolution</i>. (3)1715-1724.