---
title: "Metabolic flux analysis using 13C peptide label measurements"
collection: publications
permalink: /publication/2013-11-26-https://onlinelibrary.wiley.com/doi/full/10.1111/tpj.12390
date: 2013-11-26
venue: 'Plant Journal'
paperurl: 'http://jgoldford.github.io/files/Mandy_PlantJ_2013.pdf'
citation: 'Mandy, D., Goldford, J.E., Yang, H., Allen, D., &amp; Libourel, I. Metabolic flux analysis using 13C peptide label measurements. <i>Plant Journal</i>. 2014 Feb; 77(3): 476-86'
---

<a href='http://jgoldford.github.io/files/Mandy_PlantJ_2013.pdf'>Download paper here</a>

Recommended citation: Mandy, D., Goldford, J.E., Yang, H., Allen, D., & Libourel, I. Metabolic flux analysis using 13C peptide label measurements. <i>Plant Journal</i>. 2014 Feb; 77(3): 476-86