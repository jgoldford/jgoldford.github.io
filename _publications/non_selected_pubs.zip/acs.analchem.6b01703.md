---
title: "Unsupervised Identification of Isotope Labeled Peptides."
collection: publications
permalink: /publication/2016-05-04-https://pubs.acs.org/doi/abs/10.1021/acs.analchem.6b01703
date: 2016-05-04
venue: 'Analytical Chemistry'
paperurl: 'http://jgoldford.github.io/files/Goldford_AnalChem_2016.pdf'
citation: 'Goldford, J.E. and Libourel, I. Unsupervised Identification of Isotope Labeled Peptides. <i>Analytical Chemistry</i>. 2016 Jun 7;88(11) 6092-6099'
---

<a href='http://jgoldford.github.io/files/Goldford_AnalChem_2016.pdf'>Download paper here</a>

Recommended citation: Goldford, J.E. and Libourel, I. Unsupervised Identification of Isotope Labeled Peptides. <i>Analytical Chemistry</i>. 2016 Jun 7;88(11) 6092-6099